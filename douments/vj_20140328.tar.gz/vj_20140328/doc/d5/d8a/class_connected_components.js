var class_connected_components =
[
    [ "Similarity", "db/db5/struct_connected_components_1_1_similarity.html", "db/db5/struct_connected_components_1_1_similarity" ],
    [ "ConnectedComponents", "d5/d8a/class_connected_components.html#a15718b1951e5ba90be52a0823be37161", null ],
    [ "clear", "d5/d8a/class_connected_components.html#a87f770f0d74fbdf27d79b79b92b655b0", null ],
    [ "connected", "d5/d8a/class_connected_components.html#a4caa9fad9b2d097275bfd2fecefbfc94", null ],
    [ "is_equivalent", "d5/d8a/class_connected_components.html#a5547fb6f69705aaeaa69f58c0294ceb7", null ],
    [ "is_root_label", "d5/d8a/class_connected_components.html#a72ac404b0f1677a06e1c11d57b8b33f9", null ],
    [ "label_image", "d5/d8a/class_connected_components.html#a5651b97ce6dd08fe00680bd2440ebb9f", null ],
    [ "merge", "d5/d8a/class_connected_components.html#a11201561cdbd1c0ca4538470b370b1bf", null ],
    [ "new_label", "d5/d8a/class_connected_components.html#a1a288875aa35455af858f2244cb119af", null ],
    [ "relabel_image", "d5/d8a/class_connected_components.html#a797a424b05d58e3651be131410933e24", null ],
    [ "root_of", "d5/d8a/class_connected_components.html#a6e7bb2283fc281323209e44318ab19ec", null ],
    [ "highest_label", "d5/d8a/class_connected_components.html#ac68339536a3ab7c0e02394852c41f44d", null ],
    [ "labels", "d5/d8a/class_connected_components.html#a2f3f4a935b73394a0527c1039e57c3c4", null ]
];