var structstump_rule =
[
    [ "featureIndex", "d9/daf/structstump_rule.html#a5f2a11545b1c84f495143a66487e0235", null ],
    [ "margin", "d9/daf/structstump_rule.html#af466999830ad028495631363cb989466", null ],
    [ "threshold", "d9/daf/structstump_rule.html#a3d2d282ad0072b1fe41d506036fca056", null ],
    [ "toggle", "d9/daf/structstump_rule.html#ae8fb8b7b98348a2c268f538c623b0d22", null ],
    [ "weightedError", "d9/daf/structstump_rule.html#ab61908110a4ea328c46301f6e844e6a3", null ]
];