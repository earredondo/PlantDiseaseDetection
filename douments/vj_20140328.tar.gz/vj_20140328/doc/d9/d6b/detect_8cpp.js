var detect_8cpp =
[
    [ "MIN_FRIENDS", "d9/d6b/detect_8cpp.html#a6d9ad3cef46c74a2ac6b249313fb2d2c", null ],
    [ "main", "d9/d6b/detect_8cpp.html#ad1835a0a190dc5fe4f925bb69443c770", null ]
];