var boost_util_8h =
[
    [ "trainParams", "db/ddd/structtrain_params.html", "db/ddd/structtrain_params" ],
    [ "recordRule", "dd/d4e/boost_util_8h.html#a5f16e085e138db72a5ffc1cdc30a2e97", null ],
    [ "train", "dd/d4e/boost_util_8h.html#a85b650e0144234e9460732c21c541888", null ]
];