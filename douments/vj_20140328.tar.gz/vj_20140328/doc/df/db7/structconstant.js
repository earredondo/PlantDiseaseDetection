var structconstant =
[
    [ "operator T", "df/db7/structconstant.html#a6e5a1cefa3a0a47f8dce5767eb6cff45", null ]
];