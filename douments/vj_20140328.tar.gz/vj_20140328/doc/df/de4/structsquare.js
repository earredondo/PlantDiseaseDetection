var structsquare =
[
    [ "pos_i", "df/de4/structsquare.html#a6e334cb9aafa5060e74600650dbceaa1", null ],
    [ "pos_j", "df/de4/structsquare.html#a5ea5ab1474eec639268f93e8875d478e", null ],
    [ "side", "df/de4/structsquare.html#a56c3e15e6621d7e1e4c0182c0e188aa7", null ]
];