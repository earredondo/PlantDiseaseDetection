var train_8cpp =
[
    [ "LAYER_DETECTION_RATE", "de/dc7/train_8cpp.html#a33b7efcd956e8c69d68745de00f84497", null ],
    [ "LAYER_FALSE_POSITIVE", "de/dc7/train_8cpp.html#ac8b8d3efc74d6b1ca469720a0aa8b938", null ],
    [ "OVERALL_DETECTION_RATE", "de/dc7/train_8cpp.html#af036e25173a1b358f4198c4919d68ef1", null ],
    [ "OVERALL_FALSE_POSITIVE", "de/dc7/train_8cpp.html#ae028a25933cc3f0911313ca1970b70d6", null ],
    [ "main", "de/dc7/train_8cpp.html#ad1835a0a190dc5fe4f925bb69443c770", null ]
];