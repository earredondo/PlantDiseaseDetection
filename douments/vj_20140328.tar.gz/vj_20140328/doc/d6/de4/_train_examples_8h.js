var _train_examples_8h =
[
    [ "stumpRule", "d9/daf/structstump_rule.html", "d9/daf/structstump_rule" ],
    [ "TrainExamples", "de/d6e/class_train_examples.html", "de/d6e/class_train_examples" ],
    [ "VectorXld", "d6/de4/_train_examples_8h.html#a82f3434c25d99f44bcd3b69a87cf2bfc", null ]
];