var files =
[
    [ "boostUtil.cpp", "dd/ddd/boost_util_8cpp.html", "dd/ddd/boost_util_8cpp" ],
    [ "boostUtil.h", "dd/d4e/boost_util_8h.html", "dd/d4e/boost_util_8h" ],
    [ "commonUtil.cpp", "dd/d4b/common_util_8cpp.html", "dd/d4b/common_util_8cpp" ],
    [ "commonUtil.h", "d1/db9/common_util_8h.html", "d1/db9/common_util_8h" ],
    [ "connected.h", "d7/d12/connected_8h.html", [
      [ "constant", "df/db7/structconstant.html", "df/db7/structconstant" ],
      [ "ConnectedComponents", "d5/d8a/class_connected_components.html", "d5/d8a/class_connected_components" ],
      [ "Similarity", "db/db5/struct_connected_components_1_1_similarity.html", "db/db5/struct_connected_components_1_1_similarity" ]
    ] ],
    [ "detect.cpp", "d9/d6b/detect_8cpp.html", "d9/d6b/detect_8cpp" ],
    [ "Detector.cpp", "d1/ddb/_detector_8cpp.html", null ],
    [ "Detector.h", "d0/d46/_detector_8h.html", [
      [ "Detector", "d2/d27/class_detector.html", "d2/d27/class_detector" ]
    ] ],
    [ "detectUtil.cpp", "d5/dc3/detect_util_8cpp.html", "d5/dc3/detect_util_8cpp" ],
    [ "detectUtil.h", "d0/d4c/detect_util_8h.html", "d0/d4c/detect_util_8h" ],
    [ "io_png.h", "dd/d7d/io__png_8h.html", "dd/d7d/io__png_8h" ],
    [ "train.cpp", "de/dc7/train_8cpp.html", "de/dc7/train_8cpp" ],
    [ "TrainExamples.cpp", "d6/d73/_train_examples_8cpp.html", "d6/d73/_train_examples_8cpp" ],
    [ "TrainExamples.h", "d6/de4/_train_examples_8h.html", "d6/de4/_train_examples_8h" ]
];