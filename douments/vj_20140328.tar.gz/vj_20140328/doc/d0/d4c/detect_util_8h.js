var detect_util_8h =
[
    [ "square", "df/de4/structsquare.html", "df/de4/structsquare" ],
    [ "MatrixXld", "d0/d4c/detect_util_8h.html#a4d177f71b87cbed692a018cb60a0b16f", null ],
    [ "computeFeature", "d0/d4c/detect_util_8h.html#a63ceaca7bfee83324da5a3c8b25a4dd9", null ],
    [ "computeHaarLikeFeatures", "d0/d4c/detect_util_8h.html#acaa858ade1d73bd17f4c60755e660387", null ],
    [ "convertToColor", "d0/d4c/detect_util_8h.html#a5eb14078429c87fe59b7c5fb0c86423a", null ],
    [ "detectFace", "d0/d4c/detect_util_8h.html#ab308ea0b563fc8235cd5311120e627ee", null ],
    [ "exampleScan", "d0/d4c/detect_util_8h.html#ad1892a03a9f1c2589d1b59fabcb378d3", null ],
    [ "gaussianKernel", "d0/d4c/detect_util_8h.html#ad2f9c7a25d16019ed1c71012f4f03888", null ],
    [ "gaussianRowSmoothing", "d0/d4c/detect_util_8h.html#ac641733c3725257415c614c8c26bf2ab", null ],
    [ "gaussianSmoothing", "d0/d4c/detect_util_8h.html#a80d92c327213e6dd8e502ea86bbe318a", null ],
    [ "highlight", "d0/d4c/detect_util_8h.html#ac49a45c76ee920f6ecca9ae539790666", null ],
    [ "isLegal", "d0/d4c/detect_util_8h.html#aad187433b5b10d4969ba591232e95178", null ],
    [ "postProcessing", "d0/d4c/detect_util_8h.html#a87e4b26367c34daf470ceb3abeae1540", null ],
    [ "readInCascade", "d0/d4c/detect_util_8h.html#a3fe1d1556a692d838e7ea038ac11c5fa", null ],
    [ "rotateCoordinate", "d0/d4c/detect_util_8h.html#ad212990060a4719bfe797cd7342c3113", null ],
    [ "rotateImage", "d0/d4c/detect_util_8h.html#ad808a01101a99ca2ae4c65730114e4eb", null ],
    [ "round", "d0/d4c/detect_util_8h.html#ad8cbea06d2711f541098b692d3d1abc9", null ],
    [ "scan", "d0/d4c/detect_util_8h.html#a3b23deb4a706e26f490ecd3e3ea2fac2", null ],
    [ "tscan", "d0/d4c/detect_util_8h.html#acd8dc47b1c40190aba6e2fd40cb01cb4", null ],
    [ "zoomOutNegative", "d0/d4c/detect_util_8h.html#aaedc6315a0a6d78601b0af548c05640a", null ]
];