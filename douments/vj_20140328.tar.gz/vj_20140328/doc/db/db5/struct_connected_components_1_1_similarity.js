var struct_connected_components_1_1_similarity =
[
    [ "Similarity", "db/db5/struct_connected_components_1_1_similarity.html#a8a33686eed60df407cf81ce6a3ed324a", null ],
    [ "Similarity", "db/db5/struct_connected_components_1_1_similarity.html#a84bc76d9b11a054fdf95f241d858753c", null ],
    [ "Similarity", "db/db5/struct_connected_components_1_1_similarity.html#aaa44a99c371633a4df12e12e75f7efd8", null ],
    [ "id", "db/db5/struct_connected_components_1_1_similarity.html#a63f965ba621219bfb1c9b848c1391bcd", null ],
    [ "sameas", "db/db5/struct_connected_components_1_1_similarity.html#a60f76f3735b4004fabbbfa43f6a8f040", null ],
    [ "tag", "db/db5/struct_connected_components_1_1_similarity.html#af1224d223ec0bd86f81bde50ac219cfd", null ]
];