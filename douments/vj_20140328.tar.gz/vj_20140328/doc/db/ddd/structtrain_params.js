var structtrain_params =
[
    [ "allInMemory", "db/ddd/structtrain_params.html#a6013f411d4c4f13c37c0665a9c18d222", null ],
    [ "layerTargetDetectionRate", "db/ddd/structtrain_params.html#a83c5fe03e64d136ad047a6c602b9bffa", null ],
    [ "layerTargetFalsePositiveRate", "db/ddd/structtrain_params.html#aaa4cb31839e290128265298ed61ac494", null ],
    [ "negativeExamples", "db/ddd/structtrain_params.html#a5e98c60bbc251109789bb68a0929dc87", null ],
    [ "negativeTestExamples", "db/ddd/structtrain_params.html#adc61bebfd6d311003aaccb367093f8e2", null ],
    [ "overallTargetDetectionRate", "db/ddd/structtrain_params.html#a193b096ce0e96594bf42a5b05d4f1df9", null ],
    [ "overallTargetFalsePositiveRate", "db/ddd/structtrain_params.html#a3a9a883833ef9c6abbc9af05b4e732ff", null ],
    [ "positiveExamples", "db/ddd/structtrain_params.html#ab9351d032fc198f7baf9ff619ff302c3", null ],
    [ "positiveTestExamples", "db/ddd/structtrain_params.html#a24d3fe237b45abee527fc61af38643aa", null ],
    [ "positiveTotalWeight", "db/ddd/structtrain_params.html#a28ac7d7a6d91d731a2ee5990e355af03", null ],
    [ "toFile", "db/ddd/structtrain_params.html#a1ea27c844e273e1dd79c67005bfab314", null ]
];