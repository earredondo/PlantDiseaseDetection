var annotated =
[
    [ "ConnectedComponents", "d5/d8a/class_connected_components.html", "d5/d8a/class_connected_components" ],
    [ "constant", "df/db7/structconstant.html", "df/db7/structconstant" ],
    [ "Detector", "d2/d27/class_detector.html", "d2/d27/class_detector" ],
    [ "square", "df/de4/structsquare.html", "df/de4/structsquare" ],
    [ "stumpRule", "d9/daf/structstump_rule.html", "d9/daf/structstump_rule" ],
    [ "TrainExamples", "de/d6e/class_train_examples.html", "de/d6e/class_train_examples" ],
    [ "trainParams", "db/ddd/structtrain_params.html", "db/ddd/structtrain_params" ]
];