var class_detector =
[
    [ "Detector", "d2/d27/class_detector.html#aa43b3d7bbd4b225855b4bcc93f70b225", null ],
    [ "~Detector", "d2/d27/class_detector.html#ae16b7bf62f39cb287927d56ca17663d7", null ],
    [ "getCommitteSize", "d2/d27/class_detector.html#a8f030649fec283ea6c7a246a2c7c1721", null ],
    [ "getFeature", "d2/d27/class_detector.html#ac027e57462e41ca4f7440bbc5bf3b146", null ],
    [ "getFeatureCount", "d2/d27/class_detector.html#a3c66f1a154f39e0c7b2b75b3de2d606e", null ],
    [ "getLayerCount", "d2/d27/class_detector.html#a474e27080d63d9924ed038a25216b867", null ],
    [ "getSampleSize", "d2/d27/class_detector.html#a9aa68360fbd1eb6166904d275ebca229", null ],
    [ "getStumps", "d2/d27/class_detector.html#a6e9117f8668ba5deea22f211025ecf34", null ],
    [ "getTweak", "d2/d27/class_detector.html#a174b24a194945828a78e9cbc10999b21", null ],
    [ "featureCount", "d2/d27/class_detector.html#a11a4274fb0ff058cd44f4685d3baea32", null ],
    [ "featureMap", "d2/d27/class_detector.html#a3521edb94968f61f66878ec3d8e405ef", null ],
    [ "layerCommitteeSize", "d2/d27/class_detector.html#a25edd6c763ecc2531035e5ada49e0c31", null ],
    [ "layerCount", "d2/d27/class_detector.html#ac3f07231ea7642ab27c8c16db7650f4a", null ],
    [ "sampleSize", "d2/d27/class_detector.html#aa5046b65cabaa6fb7798afd25a6ac484", null ],
    [ "stumps", "d2/d27/class_detector.html#a26c5c95b5a632e3600cb0247ebbec43f", null ],
    [ "tweaks", "d2/d27/class_detector.html#a5a7452011d7bef7d6f792f859bd14702", null ]
];