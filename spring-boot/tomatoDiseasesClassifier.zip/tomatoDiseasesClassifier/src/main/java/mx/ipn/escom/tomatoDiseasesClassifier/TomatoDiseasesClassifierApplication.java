package mx.ipn.escom.tomatoDiseasesClassifier;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TomatoDiseasesClassifierApplication {

	public static void main(String[] args) {
		SpringApplication.run(TomatoDiseasesClassifierApplication.class, args);
	}
}
