# springboot-hello-world
JPA Hibernate and Web
Project with basic funcionality about srpingboot with hibernate and JSF.
